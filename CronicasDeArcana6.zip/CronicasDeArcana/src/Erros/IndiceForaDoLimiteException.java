package Erros;

public class IndiceForaDoLimiteException extends Exception{
	
	public IndiceForaDoLimiteException() {
		super("Indice fora do limite permitido.");
	}

}

package Erros;

public class NumeroForaDoLimite extends Exception{

	public NumeroForaDoLimite() {
		super("Campo de batalha cheio.");
	}
}

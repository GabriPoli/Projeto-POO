/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Encantamentos;

import Cartas.Encantamento;
import GUI.TelaCombateGUI;
import MecanicasJogo.Deck;
import MecanicasJogo.Jogadores;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author gabri
 */
public class Amazonia extends Encantamento {
    
    public Amazonia() {
        super(2, 4, 0, "BuffResistencia", "Buffa todas as Resistências das cartas da mão do tipo Criatura após ser ativada (Buff prevalece quando vão para o campo).", new ImageIcon("src\\ImagensCartas\\cartaVacuo.png").getImage());
    }

    @Override
    public void usarEncantamento(Jogadores jogador, Deck deck, TelaCombateGUI telaCombate) {
        /*if(jogador == telaCombate.getJogador1()){
        
            for(int i = 0; i < deck.getDeck1().size(); i++){
                

                    deck.getDeck1().get(i).setPoder(deck.getDeck1().get(i).getResistencia() + 2);
            
            
            }
            
        }else {
        
            for(int i = 0; i < deck.getDeck2().size(); i++){
                

                    deck.getDeck2().get(i).setPoder(deck.getDeck2().get(i).getResistencia() + 2);
                    
                

            
            
            }*/
        deck.getDeck2();
        JOptionPane.showMessageDialog(telaCombate," Amazonia foi ativado!");
    }
    
}

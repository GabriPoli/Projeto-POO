package Cartas;

import GUI.TelaCombateGUI;
import MecanicasJogo.Deck;
import MecanicasJogo.Jogadores;
import java.awt.Image;

public abstract class Encantamento extends Carta {
    
    private boolean estaAtivo;

    public Encantamento(int poder, int mana, int resistencia, String nome, String descricao, Image imagem) {
    super(poder, mana, resistencia, nome, descricao, imagem);

    }
    
    public boolean getEstaAtivo(){
    
        return estaAtivo;
    }
    
    public void setEstaAtivo(boolean estaAtivo){
    
        this.estaAtivo = estaAtivo;
    }
    
    public abstract void usarEncantamento(Jogadores jogador, Deck deck, TelaCombateGUI telaCombate);
    
    
 
}

package Feiticos;

import Cartas.*;
import GUI.TelaCombateGUI;
import MecanicasJogo.Jogadores;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Terremoto extends Feitico {


    public Terremoto() {
        super(4, 6, 0, "Terremoto", "Um forte terremoto Ã© gerado e causa dano a um inimigo.", new ImageIcon("src\\ImagensCartas\\cartaTerremoto.png").getImage());
    }


    @Override
    public void usarFeitico(Jogadores usuario, Jogadores oponente, TelaCombateGUI telaCombate) {
        if(usuario == telaCombate.getJogador1()){
            
            if(telaCombate.getCarta1Campo2() != null){
                telaCombate.getCarta1Campo2().setResistencia(telaCombate.getCarta1Campo2().getResistencia() - 4);
                
                
                if(telaCombate.getCarta1Campo2().getResistencia() < 0){
                    telaCombate.getCarta1Campo2().setResistencia(0);
                } 
                JOptionPane.showMessageDialog(telaCombate," Explosão Arcana reduziu em 3 a resistência de "+telaCombate.getCarta1Campo2().getNome());
            }
    
        
            if(telaCombate.getCarta2Campo2() != null){
                telaCombate.getCarta2Campo2().setResistencia(telaCombate.getCarta2Campo2().getResistencia() - 4);
                
                
                if(telaCombate.getCarta2Campo2().getResistencia() < 0){
                    telaCombate.getCarta2Campo2().setResistencia(0);
                } 
                JOptionPane.showMessageDialog(telaCombate," Explosão Arcana reduziu em 3 a resistência de "+telaCombate.getCarta2Campo2().getNome());
            }
         
          if(telaCombate.getCarta3Campo2() != null){
                telaCombate.getCarta3Campo2().setResistencia(telaCombate.getCarta3Campo2().getResistencia() - 4);
                
                
                if(telaCombate.getCarta3Campo2().getResistencia() < 0){
                    telaCombate.getCarta3Campo2().setResistencia(0);
                } 
                JOptionPane.showMessageDialog(telaCombate," Explosão Arcana reduziu em 3 a resistência de "+telaCombate.getCarta3Campo2().getNome());
            }
        }else if(usuario == telaCombate.getJogador2()){
        
            if(telaCombate.getCarta1Campo1() != null){
                telaCombate.getCarta1Campo1().setResistencia(telaCombate.getCarta1Campo1().getResistencia() - 4);
                
                if(telaCombate.getCarta1Campo1().getResistencia() < 0){
                    telaCombate.getCarta1Campo1().setResistencia(0);
                }
                JOptionPane.showMessageDialog(telaCombate," Explosão Arcana reduziu em 3 o poder de "+telaCombate.getCarta1Campo1().getNome());
            }
            
            if(telaCombate.getCarta2Campo1() != null){
                telaCombate.getCarta2Campo1().setResistencia(telaCombate.getCarta2Campo1().getResistencia() - 4);
                
                if(telaCombate.getCarta2Campo1().getResistencia() < 0){
                    telaCombate.getCarta2Campo1().setResistencia(0);
                } 
                JOptionPane.showMessageDialog(telaCombate," Explosão Arcana reduziu em 3 o poder de "+telaCombate.getCarta2Campo1().getNome());
            }
            
            if(telaCombate.getCarta3Campo1() != null){
                telaCombate.getCarta3Campo1().setResistencia(telaCombate.getCarta3Campo1().getResistencia() - 4);
                
                if(telaCombate.getCarta3Campo1().getResistencia() < 0){
                    telaCombate.getCarta3Campo1().setResistencia(0);
                } 
                JOptionPane.showMessageDialog(telaCombate," Explosão Arcana reduziu em 3 o poder de "+telaCombate.getCarta3Campo1().getNome());
            }
        
        }
    
    }


}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Feiticos;

import Cartas.Feitico;
import GUI.TelaCombateGUI;
import MecanicasJogo.Jogadores;
import javax.swing.ImageIcon;

/**
 *
 * @author gabri
 */
public class MaisMana extends Feitico{
    
    public MaisMana() {
	super(3, 1, 0, "Mana", "Uma energia divina surgiu e lhe concedeu 2 de mana", new ImageIcon("src\\ImagensCartas\\cartaCurar.png").getImage());
        this.setParaAtaque(false);
    }

    @Override
    public void usarFeitico(Jogadores jogador1, Jogadores jogador2, TelaCombateGUI telaCombate) {
        int novaMana = jogador1.getManaJogador() + this.getPoder();
        jogador1.setVidaJogador(novaMana);
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Feiticos;

import Cartas.Feitico;
import GUI.TelaCombateGUI;
import MecanicasJogo.Jogadores;
import javax.swing.ImageIcon;

/**
 *
 * @author gabri
 */
public class Vacuo extends Feitico{

    public Vacuo() {
        super(4, 4, 0, "Vacuo", "Uma esfera de vácuo absoluto surge no campo de batalha, sugando uma criatura inimiga.", new ImageIcon("src\\ImagensCartas\\cartaBolaDeFogo.png").getImage());
        this.setParaAtaque(true);
    }

    @Override
    public void usarFeitico(Jogadores jogador1, Jogadores jogador2, TelaCombateGUI telaCombate) {
        if (jogador2.getCarta().getResistencia() < jogador1.getCarta().getPoder()) {
            int dano = jogador1.getCarta().getPoder() - jogador2.getCarta().getResistencia();
            int vidaAtual = jogador2.getVidaJogador() - dano;
            jogador2.getCarta().setVivo(false);
            jogador2.setVidaJogador(vidaAtual);
        }
        else{
            int novaResistencia = jogador1.getCarta().getPoder() - jogador2.getCarta().getResistencia();
            jogador2.getCarta().setVivo(true);
            jogador2.getCarta().setResistencia(novaResistencia);
        }
    }

}
    


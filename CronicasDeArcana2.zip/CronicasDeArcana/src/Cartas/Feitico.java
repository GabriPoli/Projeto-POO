package Cartas;

public class Feitico extends Carta{
	
    public Feitico(int poder, int mana, int resistencia, String nome, String descricao) {
        super(poder, mana, resistencia, nome, descricao);
    }
}

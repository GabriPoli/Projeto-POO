package Cartas;

public class Encantamento extends Carta {

    private int poder;
    private String nome;
    private String descricao;

    public Encantamento(int poder, int mana, int resistencia, String nome, String descricao) {
    super(poder, mana, resistencia, nome, descricao);

    }
 
}

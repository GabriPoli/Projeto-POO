/**
 * 
 */
/**
 * 
 */
module CronicasDeArcana {
	requires java.desktop;
}
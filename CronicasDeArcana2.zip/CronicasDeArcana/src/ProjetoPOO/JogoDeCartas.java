package ProjetoPOO;

import MecanicasJogo.Jogadores;
import MecanicasJogo.Jogo;

public class JogoDeCartas {
	
    public static void main(String[] args) {
    	
    	Jogo jogo = new Jogo();
    	
    	Jogadores jogador1 = new Jogadores("Freitas", 20, 10, jogo.getListaCartas1(), jogo.getCampoDeBatalha1());
    	Jogadores jogador2 = new Jogadores("Leal", 20, 10, jogo.getListaCartas2(), jogo.getCampoDeBatalha2());

    	jogo.definirCartasDaMao(jogador1);
    	jogo.definirCartasDaMao(jogador2);
    	jogo.comecoJogo(jogador1);
        jogo.comecoJogo(jogador2);
     
        while(jogador1.getVidaJogador() > 0 && jogador2.getVidaJogador() > 0) {
  
        	jogo.executarTurno(jogador1, jogador2);
        	jogo.exibirStatus(jogador1, jogador2);
        }
        
        System.out.println("Fim de Jogo!!!");
        if(jogador1.getVidaJogador() <= 0) {
        	int xpGanho2 = jogador2.getExperiencia();
        	xpGanho2 += 2;
        	System.out.println(jogador2.getNomeJogador() + " ganhou " + xpGanho2 + "de xp.");
        }
        if(jogador2.getVidaJogador() <= 0) {
        	int xpGanho1 = jogador1.getExperiencia();
        	xpGanho1 += 2;
        	System.out.println(jogador1.getNomeJogador() + " ganhou " + xpGanho1 + "de xp.");

        }
        

        
        
        
        
        
        
        
        
        //ArrayList<Criatura> listaCriaturas = jogador1.getCriaturasLista();
        //Selecione qual carta vc quer usar para atacar seu baitola
       //for (Criatura criatura : listaCriaturas) {
		//0 - criatura.getNome();
    	   
    	   //criatura.getNome();
       //}
       
       //criaturas.get(0);
       
    }
    
   
}

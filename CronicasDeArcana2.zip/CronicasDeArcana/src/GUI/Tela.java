package GUI;

import javax.swing.*;

public class Tela extends JFrame{
	
	public Tela() {
		setTitle("Cronicas de Arcana");
        setSize(1200, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);

        // Instancia BotoesCartas e adiciona ele ao frame
        BotoesCartas cartas = new BotoesCartas();
        add(cartas);

        setVisible(true);
	}
	
	public static void main(String[] args) {
		new Tela();
	}
	
	
}

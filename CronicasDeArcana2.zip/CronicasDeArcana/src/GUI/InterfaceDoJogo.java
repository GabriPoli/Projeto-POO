package GUI;

import javax.swing.*;

import Cartas.Carta;
import Criaturas.*;
import MecanicasJogo.Jogadores;
import MecanicasJogo.Jogo;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

public class InterfaceDoJogo extends JFrame {

    private Jogo jogo;
    private JButton[] player1HandButton, player2HandButton;
    private JLabel[] battlefieldLabels;
    private JButton endTurnButton;
    private JLabel turnLabel;
    private JPanel battlefieldPanel;
    private Jogadores jogador1, jogador2;
    private Random random = new Random();
    
    private JLabel nomeJogador1Label, vidaJogador1Label;
    private JLabel nomeJogador2Label, vidaJogador2Label;

    public InterfaceDoJogo(Jogo jogo, Jogadores jogador1, Jogadores jogador2) {
        this.jogo = jogo;
        this.jogador1 = jogador1;
        this.jogador2 = jogador2;

        setTitle("Crônicas de Arcana");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 700);
        setLayout(new BorderLayout());

        // Inicializando o campo de batalha
        battlefieldPanel = new JPanel(new GridLayout(2, 5));
        battlefieldPanel.setBackground(new Color(0, 0, 0, 100));  // Fundo preto transparente
        battlefieldLabels = new JLabel[10];

        for (int i = 0; i < 10; i++) {
            battlefieldLabels[i] = new JLabel(new ImageIcon("path/to/empty_field_image.png"));
            battlefieldPanel.add(battlefieldLabels[i]);
        }
        add(battlefieldPanel, BorderLayout.CENTER);

        // Painel da mão do Jogador 1
        JPanel player1HandPanel = new JPanel(new GridLayout(1, 5));
        //player1HandPanel.setBackground(new Color(128, 128, 128, 200));  // Fundo cinza opaco
        player1HandButton = new JButton[5];
        for (int i = 0; i < 5; i++) {
            int randomNum = random.nextInt(4) + 1;
            player1HandButton[i] = new JButton(new ImageIcon("C://Cartas jogo Cronicas de Arcana//carta" + randomNum + ".png"));
            jogador1.setMaoAleatoriaGUI(jogador1.getMao(), randomNum);
            
            player1HandButton[i].setBorder(null);
            player1HandButton[i].setContentAreaFilled(false);
            player1HandButton[i].setFocusPainted(false);
            int finalI = i;
            player1HandButton[i].addActionListener(e -> {
                jogarCarta(jogador1, finalI);
                moverCartaParaCampo(jogador1, finalI);  // Move a carta para o campo de batalha
            });
            player1HandPanel.add(player1HandButton[i]);
        }
        
        jogo.cartasDaMao(jogador1);
        add(player1HandPanel, BorderLayout.SOUTH);

        // Painel da mão do Jogador 2
        JPanel player2HandPanel = new JPanel(new GridLayout(1, 5));
        //player2HandPanel.setBackground(new Color(128, 128, 128, 200));  // Fundo cinza opaco
        player2HandButton = new JButton[5];
        for (int i = 0; i < 5; i++) {
            int randomNum = random.nextInt(4) + 1;
            player2HandButton[i] = new JButton(new ImageIcon("C://Cartas jogo Cronicas de Arcana//carta" + randomNum + ".png"));
            jogador2.setMaoAleatoriaGUI(jogador2.getMao(), randomNum);
            
            player2HandButton[i].setBorder(null);
            player2HandButton[i].setContentAreaFilled(false);
            player2HandButton[i].setFocusPainted(false);
            int finalI = i;
            player2HandButton[i].addActionListener(e -> {
                jogarCarta(jogador2, finalI);
                moverCartaParaCampo(jogador2, finalI);  // Move a carta para o campo de batalha
            });
            player2HandPanel.add(player2HandButton[i]);
        }
        
        jogo.cartasDaMao(jogador2);
        add(player2HandPanel, BorderLayout.NORTH);

        // Botão de fim de turno
        endTurnButton = new JButton("Fim do Turno");
        endTurnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
            }
        });
        add(endTurnButton, BorderLayout.EAST);

        // Exibe o turno atual
        turnLabel = new JLabel("Turno do Jogador 1");
        add(turnLabel, BorderLayout.WEST);

        setVisible(true);
        
     // Painéis de informações dos jogadores (nome e vida)
        add(criarPainelInfoJogador(jogador1, true), BorderLayout.SOUTH); // Próximo à mão do Jogador 1
        add(criarPainelInfoJogador(jogador2, false), BorderLayout.NORTH); // Próximo à mão do Jogador 2

        setVisible(true);
    }

 // Método para criar o painel de informações de cada jogador
    private JPanel criarPainelInfoJogador(Jogadores jogador, boolean isJogador1) {
        JPanel painelInfo = new JPanel();
        painelInfo.setLayout(new GridLayout(2, 1));
        painelInfo.setOpaque(true);
        painelInfo.setBackground(new Color(0, 0, 128, 150)); // Azul escuro transparente

        JLabel nomeJogadorLabel = new JLabel(jogador.getNomeJogador());
        nomeJogadorLabel.setForeground(Color.WHITE);
        nomeJogadorLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel vidaJogadorLabel = new JLabel("Vida: " + jogador.getVidaJogador());
        vidaJogadorLabel.setForeground(Color.WHITE);
        vidaJogadorLabel.setHorizontalAlignment(SwingConstants.CENTER);

        painelInfo.add(nomeJogadorLabel);
        painelInfo.add(vidaJogadorLabel);

        // Salvando referências para atualizar depois
        if (isJogador1) {
            nomeJogador1Label = nomeJogadorLabel;
            vidaJogador1Label = vidaJogadorLabel;
        } else {
            nomeJogador2Label = nomeJogadorLabel;
            vidaJogador2Label = vidaJogadorLabel;
        }

        return painelInfo;
    }
    
    // Método para mover a carta da mão para o campo de batalha
    private void moverCartaParaCampo(Jogadores jogador, int indiceCarta) {
        Carta cartaSelecionada = jogador.getMao().get(indiceCarta);
        
        // Verifica se há espaço no campo de batalha
        if (jogador.getCampoDeBatalha().size() < 5) {
            // Remove a carta da mão e adiciona ao campo de batalha
            jogador.getMao().remove(indiceCarta);
            jogador.getCampoDeBatalha().add(cartaSelecionada);

            // Atualiza visualmente: adiciona a carta no campo e remove da mão
            if (jogador == jogador1) {
                battlefieldLabels[jogador.getCampoDeBatalha().size() - 1].setIcon(new ImageIcon("C://Cartas jogo Cronicas de Arcana//" + cartaSelecionada.getNome() + ".png"));
                player1HandButton[indiceCarta].setEnabled(false);  // Desabilita o botão após o uso
            } else {
                battlefieldLabels[jogador.getCampoDeBatalha().size() + 4].setIcon(new ImageIcon("C://Cartas jogo Cronicas de Arcana//" + cartaSelecionada.getNome() + ".png"));
                player2HandButton[indiceCarta].setEnabled(false);  // Desabilita o botão após o uso
            }

            // Após mover para o campo, exibe a janela de opções
            mostrarOpcoesCarta();
        } else {
            JOptionPane.showMessageDialog(this, "Campo de batalha cheio!");
        }
    }

    // Método para exibir a janela com as opções "Atacar" e "Habilidade"
    private void mostrarOpcoesCarta() {
        JDialog dialog = new JDialog(this, "Opções da Carta", true);
        dialog.setLayout(new FlowLayout());
        dialog.setSize(200, 100);

        JButton atacarButton = new JButton("Atacar");
        JButton habilidadeButton = new JButton("Habilidade");

        atacarButton.addActionListener(e -> {
            // Lógica para atacar
            dialog.dispose();
        });

        habilidadeButton.addActionListener(e -> {
            // Lógica para usar habilidade
            dialog.dispose();
        });

        dialog.add(atacarButton);
        dialog.add(habilidadeButton);

        dialog.setLocationRelativeTo(this);  // Centraliza a janela
        dialog.setVisible(true);
    }

    private void jogarCarta(Jogadores jogador, int indiceCarta) {
        if (jogo.getjogadorAtivo() == jogador.getNomeJogador().equals(jogador1.getNomeJogador())) {
            Carta cartaSelecionada = jogador.getMao().get(indiceCarta);
            jogo.cartasDoCampo(jogador, cartaSelecionada);
            updateUI(jogador, cartaSelecionada);
        }
    }


    public void updateUI(Jogadores jogador, Carta cartaJogada) {
        ArrayList<Carta> campoAtual = jogador.getCampoDeBatalha();
        int posicaoCampo = jogador == jogador1 ? 0 : 5; // Campo do Jogador 1 é de 0 a 4, Jogador 2 de 5 a 9
        for (int i = 0; i < campoAtual.size(); i++) {
            battlefieldLabels[posicaoCampo + i].setIcon(new ImageIcon("C://Cartas jogo Cronicas de Arcana//" + cartaJogada.getNome() + ".png"));
        }
    }

    private void updateTurnLabel() {
        String currentTurn = jogo.getjogadorAtivo() ? "Jogador 1" : "Jogador 2";
        turnLabel.setText("Turno do " + currentTurn);
    }

    public static void main(String[] args) {
        // Inicializando os jogadores
        
        Jogo jogo = new Jogo();
        
        Jogadores jogador1 = new Jogadores("Freitas", 20, 10, jogo.getListaCartas1(), jogo.getCampoDeBatalha1());
    	Jogadores jogador2 = new Jogadores("Leal", 20, 10, jogo.getListaCartas2(), jogo.getCampoDeBatalha2());
        
        InterfaceDoJogo gui = new InterfaceDoJogo(jogo, jogador1, jogador2);
        
        jogo.comecoJogo(jogador1);
        jogo.comecoJogo(jogador2);
        
        while(jogador1.getVidaJogador() > 0 && jogador2.getVidaJogador() > 0) {
        	  
        	jogo.executarTurno(jogador1, jogador2);
        	jogo.exibirStatus(jogador1, jogador2);
        }
    }
}


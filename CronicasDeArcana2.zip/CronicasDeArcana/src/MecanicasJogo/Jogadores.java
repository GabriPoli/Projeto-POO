package MecanicasJogo;
import java.util.Random;
import java.util.ArrayList;

import Criaturas.*;
import Feiticos.*;
import Cartas.Carta;
public class Jogadores {

	private String nomeJogador;
	private int vidaJogador;
	private int manaJogador;
	private Carta criatura;
	//Novo
	private ArrayList<Carta> mao;
	private ArrayList<Carta> campoDeBatalha;
	private Random random = new Random();
	private int experiencia = 0;
	
	public Jogadores(String nome, int vida, int mana, ArrayList<Carta> mao, ArrayList<Carta> campoDeBatalha ) {
    	
    	this.nomeJogador = nome;
    	this.vidaJogador = vida;
    	this.manaJogador = mana;
    	this.mao = mao;
    	//Novo
    	this.campoDeBatalha = campoDeBatalha;
    }
	
	public void gastaMana(int manaGasta) {
		manaJogador = manaJogador - manaGasta;
	}
	
	public void perdeVida(int dano) {
		vidaJogador = vidaJogador - dano;
	}
	
	public void ganhaVida(int cura) {
		vidaJogador = vidaJogador + cura;
	}
	
	public int getVidaJogador() {
		return vidaJogador;
	}
	public int getManaJogador() {
		return manaJogador;
	}

	public String getNomeJogador() {
		return nomeJogador;
	}

	public void setNomeJogador(String nomeJogador) {
		this.nomeJogador = nomeJogador;
	}

	public void setVidaJogador(int vidaJogador) {
		this.vidaJogador = vidaJogador;
	}

	public void setManaJogador(int manaJogador) {
		this.manaJogador = manaJogador;
	}
	
	public int getExperiencia() {
		return experiencia;
	}

	public Carta getCriatura() {
		return criatura;
	}

	public void setCriatura(Carta criatura) {
		this.criatura = criatura;
	}

	public ArrayList<Carta> getMao() {
		return mao;
	}

	public void setMaoAleatoria(ArrayList<Carta> mao) {
		int randomNum = random.nextInt(4) + 1; // Gera números de 1 a 4
	    Carta carta;
	    switch (randomNum) {
	        case 1: carta = new Cerbero(); break;
	        case 2: carta = new Minotauro(); break;
	        case 3: carta = new Hidra(); break;
	        case 4: carta = new Grifo(); break;
	        //case 5: carta = new Terremoto(); break;
	        default: carta = null; // Não deve ocorrer, mas é uma precaução
	    }
	    if (carta != null) {
	        mao.add(carta); // Adiciona a carta gerada à lista
	    }
    }
	
	public void setMaoAleatoriaGUI(ArrayList<Carta> mao, int numeroCarta) {
	    Carta carta;
	    switch (numeroCarta) {
	        case 1: carta = new Cerbero(); break;
	        case 2: carta = new Minotauro(); break;
	        case 3: carta = new Hidra(); break;
	        case 4: carta = new Grifo(); break;
	        default: carta = null; // Não deve ocorrer, mas é uma precaução
	    }
	    if (carta != null) {
	        mao.add(carta); // Adiciona a carta gerada à lista
	    }
    }

	public boolean isEmpty() {
	    return mao == null || mao.isEmpty();
	}
	
	//Novo
	public ArrayList<Carta> getCampoDeBatalha() {
		return campoDeBatalha;
	}

	public void setCampoDeBatalha(ArrayList<Carta> campoDeBatalha) {
		this.campoDeBatalha = campoDeBatalha;
	}
	
	public void aumentarVida(int quantidade) {

        this.vidaJogador += quantidade;

    }
	
	
}

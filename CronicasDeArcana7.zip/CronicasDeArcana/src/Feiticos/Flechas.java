/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Feiticos;

import Cartas.Feitico;
import GUI.TelaCombateGUI;
import MecanicasJogo.Jogadores;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author gabri
 */
public class Flechas extends Feitico {
    
    public Flechas() {
        super(3, 5, 0, "Flechas", "Chuva de Flechas atinge o campo de batalha inimigo!", new ImageIcon("src\\ImagensCartas\\cartaFlechas.png").getImage());
        this.setParaAtaque(false);
    } 

    @Override
    public void usarFeitico(Jogadores usuario, Jogadores oponente, TelaCombateGUI telaCombate) {
        if(usuario == telaCombate.getJogador1()){
            
            if(telaCombate.getCarta1Campo2() != null){
                telaCombate.getCarta1Campo2().setResistencia(telaCombate.getCarta1Campo2().getResistencia() - 3);
                
                
                if(telaCombate.getCarta1Campo2().getResistencia() < 0){
                    telaCombate.getCarta1Campo2().setResistencia(0);
                } 
                JOptionPane.showMessageDialog(telaCombate," Flecha reduziu em 3 a resistência de "+telaCombate.getCarta1Campo2().getNome());
            }
    
        
            if(telaCombate.getCarta2Campo2() != null){
                telaCombate.getCarta2Campo2().setResistencia(telaCombate.getCarta2Campo2().getResistencia() - 3);
                
                
                if(telaCombate.getCarta2Campo2().getResistencia() < 0){
                    telaCombate.getCarta2Campo2().setResistencia(0);
                } 
                JOptionPane.showMessageDialog(telaCombate," Flecha reduziu em 3 a resistência de "+telaCombate.getCarta2Campo2().getNome());
            }
         
          if(telaCombate.getCarta3Campo2() != null){
                telaCombate.getCarta3Campo2().setResistencia(telaCombate.getCarta3Campo2().getResistencia() - 3);
                
                
                if(telaCombate.getCarta3Campo2().getResistencia() < 0){
                    telaCombate.getCarta3Campo2().setResistencia(0);
                } 
                JOptionPane.showMessageDialog(telaCombate," Flecha reduziu em 3 a resistência de "+telaCombate.getCarta3Campo2().getNome());
            }
        }else if(usuario == telaCombate.getJogador2()){
        
            if(telaCombate.getCarta1Campo1() != null){
                telaCombate.getCarta1Campo1().setResistencia(telaCombate.getCarta1Campo1().getResistencia() - 3);
                
                if(telaCombate.getCarta1Campo1().getResistencia() < 0){
                    telaCombate.getCarta1Campo1().setResistencia(0);
                }
                JOptionPane.showMessageDialog(telaCombate," Flecha reduziu em 3 a resistência de "+telaCombate.getCarta1Campo1().getNome());
            }
            
            if(telaCombate.getCarta2Campo1() != null){
                telaCombate.getCarta2Campo1().setResistencia(telaCombate.getCarta2Campo1().getResistencia() - 3);
                
                if(telaCombate.getCarta2Campo1().getResistencia() < 0){
                    telaCombate.getCarta2Campo1().setResistencia(0);
                } 
                JOptionPane.showMessageDialog(telaCombate," Flecha reduziu em 3 a resistência de "+telaCombate.getCarta2Campo1().getNome());
            }
            
            if(telaCombate.getCarta3Campo1() != null){
                telaCombate.getCarta3Campo1().setResistencia(telaCombate.getCarta3Campo1().getResistencia() - 3);
                
                if(telaCombate.getCarta3Campo1().getResistencia() < 0){
                    telaCombate.getCarta3Campo1().setResistencia(0);
                } 
                JOptionPane.showMessageDialog(telaCombate," Flecha reduziu em 3 a resistência de "+telaCombate.getCarta3Campo1().getNome());
            }
        
        }
    }
    
}

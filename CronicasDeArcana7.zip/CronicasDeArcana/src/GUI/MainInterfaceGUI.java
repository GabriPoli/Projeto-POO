/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package GUI;

import GUI.TelaCombateGUI;

/**
 *
 * @author gabri
 */
public class MainInterfaceGUI {

    public static void main(String[] args) {
        System.out.println("Cronicas de Arcana");
        TelaLogin formMainJF = new TelaLogin();
        formMainJF.setVisible(true);
        formMainJF.setLocationRelativeTo(null);
    }
}

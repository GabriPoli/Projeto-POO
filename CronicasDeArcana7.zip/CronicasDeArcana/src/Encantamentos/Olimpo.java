/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Encantamentos;

import Cartas.Criatura;
import Cartas.Encantamento;
import Cartas.Feitico;
import GUI.TelaCombateGUI;
import MecanicasJogo.Deck;
import MecanicasJogo.Jogadores;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author gabri
 */
public class Olimpo extends Encantamento{
    
    public Olimpo() {
        super(2, 4, 0, "BuffDano", "Buffa todos os poderes cartas da mão do tipo Criatura após ser ativada (Buff prevalece quando vão para o campo).", new ImageIcon("src\\ImagensCartas\\cartaOlimpo.png").getImage());
    }

    @Override
    public void usarEncantamento(Jogadores jogador, Deck deck, TelaCombateGUI telaCombate) {
        
        /*if(jogador == telaCombate.getJogador1()){
        
            for(int i = 0; i < deck.getDeck1().size(); i++){
                

                    deck.getDeck1().get(i).setPoder(deck.getDeck1().get(i).getPoder() + 2);
            
            
            }
            
        }else {
        
            for(int i = 0; i < deck.getDeck2().size(); i++){
                

                    deck.getDeck2().get(i).setPoder(deck.getDeck2().get(i).getPoder() + 2);
                    
                

            
            
            }*/
        deck.getDeck1();
        JOptionPane.showMessageDialog(telaCombate," Olimpo foi ativado! ");
        
        }
        
}
    


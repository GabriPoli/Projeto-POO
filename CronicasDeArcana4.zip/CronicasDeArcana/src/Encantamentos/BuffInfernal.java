package Encantamentos;
import java.util.ArrayList;

import Cartas.*;
import MecanicasJogo.Jogadores;

public class BuffInfernal extends Encantamento {
public BuffInfernal() {
        super(3, 5, 0, "Buff Infernal!", "As criaturas do tipo fogo do seu deck estão buffadas!", null);
    }

public void buffar(ArrayList<Criatura> criaturas ) {


}

}

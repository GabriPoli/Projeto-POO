package Erros;

public class ManaInsuficienteException extends Exception{

	public ManaInsuficienteException() {
		super("Mana insuficiente.");
	}
}

package CriaturasDeck2;

import Cartas.Criatura;
import MecanicasJogo.Jogadores;

public class Saci extends Criatura{

	public Saci() {
		super(5, 1, 0, 1, "Saci", "-", null);
	}

    @Override
    public void usarHabilidade(Jogadores jogador1, Jogadores jogador2) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

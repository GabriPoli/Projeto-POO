package CriaturasDeck2;

import Cartas.Criatura;
import MecanicasJogo.Jogadores;

public class Boitata extends Criatura{

	public Boitata() {

		super(7, 2, 0, 5, "Boitatá", "-", null);
	}
	
	public void habilidadeEspecial() {
		
	}


    @Override
    public void usarHabilidade(Jogadores jogador1, Jogadores jogador2) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

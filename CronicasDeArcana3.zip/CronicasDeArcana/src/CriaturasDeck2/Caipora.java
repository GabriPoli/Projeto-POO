package CriaturasDeck2;

import Cartas.Criatura;
import MecanicasJogo.Jogadores;

public class Caipora extends Criatura{

	public Caipora() {

		super(6, 1, 0, 2, "Caipora", "-", null);
	}
	
	public void habilidadeEspecial() {
		
	}

    @Override
    public void usarHabilidade(Jogadores jogador1, Jogadores jogador2) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
}

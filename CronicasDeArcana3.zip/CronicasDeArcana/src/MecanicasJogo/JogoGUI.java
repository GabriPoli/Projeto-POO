package MecanicasJogo;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import Erros.*;
import Feiticos.*;
import Criaturas.*;
import Cartas.*;

public class JogoGUI {

	private Jogadores jogador;
	private int turno = 1;
	private boolean isJogador1 = true;
	private ArrayList<Carta> mao1;
	private ArrayList<Carta> mao2;
	private ArrayList<Carta> campoDeBatalha1;
	private ArrayList<Carta> campoDeBatalha2;
	private Random random = new Random();
	public int jogarDeNovo = 1;
        private ArrayList<Carta> deck1;
	private ArrayList<Carta> deck2;

	public JogoGUI() {
		mao1 = new ArrayList<Carta>();
		mao2 = new ArrayList<Carta>();
	}

	Cemiterio cemiterio = new Cemiterio();
	
	public void definirCartasDaMao(Jogadores jogador, Carta carta1, Carta carta2, Carta carta3, Carta carta4, Carta carta5) {
                
            Deck deck = new Deck(); 
            
		for (int i = 0; i < 5; i++) {
			jogador.setMaoAleatoriaDeck1(jogador.getMao(), deck);
		}

                carta1 = jogador.getMao().get(0);
                carta2 = jogador.getMao().get(1);
                carta3 = jogador.getMao().get(2);
                carta4 = jogador.getMao().get(3);
                carta5 = jogador.getMao().get(4);
	}

	public void cartasDaMao(Jogadores maoJogador) {//Metodo provavelmente não sera utilizado na interface

		if (maoJogador != null && !maoJogador.isEmpty()) {
			
			if (isJogador1) {
				System.out.println("Mão de " + maoJogador.getNomeJogador());

				for (int i = 0; i < mao1.size(); i++) {
					System.out.println((i + 1) + " - " + mao1.get(i).getNome());
				}
			} else {
				mao2 = maoJogador.getMao();
				System.out.println("Mão de " + maoJogador.getNomeJogador());

				for (int i = 0; i < mao2.size(); i++) {
					System.out.println((i + 1) + " - " + mao2.get(i).getNome());
				}
			}
		}
		
		else {
	        System.out.println("A mão de " + jogador.getNomeJogador() + " está vazia.");
	    }
	}
	
	public void cartasDoCampo(Jogadores campo, Carta cartaParaCampo) {

		if (isJogador1) {
			mao1.remove(cartaParaCampo);
			campoDeBatalha1 = new ArrayList<Carta>();
			campoDeBatalha1.add(cartaParaCampo);
			System.out.println("Campo de batalha de " + campo.getNomeJogador());

			for (int i = 0; i < campoDeBatalha1.size(); i++) {
				System.out.println((i + 1) + " - " + campoDeBatalha1.get(i).getNome());
			}
		} else {
			mao2.remove(cartaParaCampo);
			campoDeBatalha2 = new ArrayList<Carta>();
			campoDeBatalha2.add(cartaParaCampo);
			System.out.println("Campo de batalha de " + campo.getNomeJogador());

			for (int i = 0; i < campoDeBatalha2.size(); i++) {
				System.out.println((i + 1) + " - " + campoDeBatalha2.get(i).getNome());
			}
		}

	}

	public void comecoJogo(Jogadores jogador) throws NumeroForaDoLimite {

		Scanner escolhaJogador = new Scanner(System.in);
		int novaMana;
		
	    if (isJogador1) {
	        cartasDaMao(jogador);
	        System.out.println(jogador.getNomeJogador() + ", digite o número da carta que deseja usar: ");
	        int criatura1 = escolhaJogador.nextInt();
	        if ((criatura1 >= 1) && (criatura1 <= 5)) {
	            Carta criaturaJogador1 = mao1.get(criatura1 - 1);
	            jogador.setCarta(criaturaJogador1);
	            cartasDoCampo(jogador, jogador.getCarta());
	            //Novo
	            novaMana = jogador.getManaJogador() - criaturaJogador1.getMana();
	            jogador.setManaJogador(novaMana);
	            
	            isJogador1 = false;

	        } else {
	            throw new NumeroForaDoLimite();
	        }
	    } 
	    else {
	        cartasDaMao(jogador);
	        System.out.println(jogador.getNomeJogador() + ", digite o número da carta que deseja usar: ");
	        int criatura2 = escolhaJogador.nextInt();
	        if ((criatura2 >= 1) && (criatura2 <= 5)) {

	            Carta criaturaJogador2 = mao2.get(criatura2 - 1);
	            jogador.setCarta(criaturaJogador2);
	            cartasDoCampo(jogador, jogador.getCarta());

	            //Novo
	            novaMana = jogador.getManaJogador() - criaturaJogador2.getMana();
	            jogador.setManaJogador(novaMana);
	            
	            isJogador1 = true;
	        } else {
	            throw new NumeroForaDoLimite();
	        }
	    }

	}

	public void exibirStatus(Jogadores jogador1, Jogadores jogador2) {
		System.out.println("===== Status Atual =====");
		System.out.println("Vida do Jogador 1: " + jogador1.getVidaJogador());
		System.out.println("Mana do Jogador 1: " + jogador1.getManaJogador());
		System.out.println("------------------------");
		System.out.println("Vida do Jogador 2: " + jogador2.getVidaJogador());
		System.out.println("Mana do Jogador 2: " + jogador2.getManaJogador());
		System.out.println("========================");
		
		//Novo
		jogador1.setManaJogador(jogador1.getManaJogador() + 1);
		jogador2.setManaJogador(jogador2.getManaJogador() + 1);
	}

	public void executarTurno(Jogadores jogador1, Jogadores jogador2) throws NumeroForaDoLimite {

		System.out.println("Turno " + turno);

		Scanner escolha = new Scanner(System.in);
		
		if (isJogador1) {
			
			if(campoDeBatalha1.size() == 0) {
				comecoJogo(jogador1);
				isJogador1 = true;
				
				System.out.println(jogador1.getNomeJogador() + " o que deseja fazer?");
				System.out.println("1-Ataque");
				System.out.println("2-Ataque com Feitiço");
				int acao1;
				acao1 = escolha.nextInt();
				
				if(acao1 == 1) {
					isJogador1 = false;
					atacar(jogador1, jogador2);
					
					if(jogador2.getCarta().isVivo() == false) {
						System.out.println(jogador1.getCarta().getNome()+" destruiu "+jogador2.getCarta().getNome());
						campoDeBatalha2.remove(jogador2.getCarta());
						//Novo
						jogador2.cartaProCemiterio2(jogador2.getCarta(), cemiterio);
					}
				}
				
				if (acao1 == 2) {
				    isJogador1 = false;
                                    atacarComFeitico(jogador1, jogador2);
                                    if (jogador2.getCarta().isVivo() == false) {
                                        System.out.println(jogador1.getCarta().getNome() + " destruiu " + jogador2.getCarta().getNome());
                                        campoDeBatalha2.remove(jogador2.getCarta());
                                        campoDeBatalha1.remove(jogador1.getCarta());
                                    }
				}
			}
			else {
				cartasDoCampo(jogador1, jogador1.getCarta());
				System.out.println(jogador1.getNomeJogador() + " o que deseja fazer?");
				System.out.println("1-Ataque");
				System.out.println("2-Ataque com Feitiço");
				int acao1;
				acao1 = escolha.nextInt();
				
				if(acao1 == 1) {
					isJogador1 = false;
					atacar(jogador1, jogador2);
					
					if(jogador2.getCarta().isVivo() == false) {
						System.out.println(jogador1.getCarta().getNome()+" destruiu "+jogador2.getCarta().getNome());
						campoDeBatalha2.remove(jogador2.getCarta());
					}
				}
				
				if (acao1 == 2) {
				    isJogador1 = false;
                                    atacarComFeitico(jogador1, jogador2);
                                    if (jogador2.getCarta().isVivo() == false) {
                                        System.out.println(jogador1.getCarta().getNome() + " destruiu " + jogador2.getCarta().getNome());
                                        campoDeBatalha2.remove(jogador2.getCarta());
                                        campoDeBatalha1.remove(jogador1.getCarta());
                                    }
				}
			}
		} 
		
		else {
			
			if(campoDeBatalha2.size() == 0) {
				comecoJogo(jogador2);
				isJogador1 = false;
				
				System.out.println(jogador2.getNomeJogador() + " o que deseja fazer?");
				System.out.println("1-Ataque");
				System.out.println("1-Ataque com Feitiço");
				int acao1;
				acao1 = escolha.nextInt();
				
				if(acao1 == 1) {
					isJogador1 = true;
					atacar(jogador2, jogador1);
					
					if(jogador1.getCarta().isVivo() == false) {
						System.out.println(jogador2.getCarta().getNome()+" destruiu "+jogador1.getCarta().getNome());
						campoDeBatalha1.remove(jogador1.getCarta());
						//Novo
						jogador1.cartaProCemiterio2(jogador1.getCarta(), cemiterio);
					}
				}
				
				if (acao1 == 2) {
				    isJogador1 = false;
                                    atacarComFeitico(jogador1, jogador2);
                                    if (jogador2.getCarta().isVivo() == false) {
                                        System.out.println(jogador1.getCarta().getNome() + " destruiu " + jogador2.getCarta().getNome());
                                        campoDeBatalha2.remove(jogador2.getCarta());
                                        campoDeBatalha1.remove(jogador1.getCarta());
                                    }
				}
			}
			else {
				cartasDoCampo(jogador2, jogador2.getCarta());
				System.out.println(jogador2.getNomeJogador() + " o que deseja fazer?");
				System.out.println("1-Ataque");
				System.out.println("2-Ataque com Feitiço");
				int acao1;
				acao1 = escolha.nextInt();
				
				if(acao1 == 1) {
					isJogador1 = true;
					atacar(jogador2, jogador1);
					
					if(jogador1.getCarta().isVivo() == false) {
						System.out.println(jogador2.getCarta().getNome()+" destruiu "+jogador1.getCarta().getNome());
						campoDeBatalha1.remove(jogador1.getCarta());
					}
				}
				
				if (acao1 == 2) {
				    isJogador1 = false;
                                    atacarComFeitico(jogador1, jogador2);
                                    if (jogador2.getCarta().isVivo() == false) {
                                        System.out.println(jogador1.getCarta().getNome() + " destruiu " + jogador2.getCarta().getNome());
                                        campoDeBatalha2.remove(jogador2.getCarta());
                                        campoDeBatalha1.remove(jogador1.getCarta());
                                    }
				}
			}
		}

		System.out.println("Fim do truno " + turno);
		turno++;
	}

	public void atacarComFeitico(Jogadores jogadorAtaque, Jogadores jogadorDefesa) {
        
            if (jogadorDefesa.getCarta().getResistencia() < jogadorAtaque.getCarta().getPoder()) {
                int dano = jogadorAtaque.getCarta().getPoder() - jogadorDefesa.getCarta().getResistencia();
                int vidaAtual = jogadorDefesa.getVidaJogador() - dano;
                jogadorDefesa.getCarta().setVivo(false);
                jogadorDefesa.setVidaJogador(vidaAtual);
            }
        }
	
	public void atacar(Jogadores jogadorAtaque, Jogadores jogadorDefesa) {

            int poderAtaque = jogadorAtaque.getCarta().getPoder();
            int resistenciaDefesa = jogadorDefesa.getCarta().getResistencia();
            //System.out.println("Poder de ataque: " + poderAtaque);
            //System.out.println("Resistência inicial do jogadorDefesa: " + resistenciaDefesa);

            if (resistenciaDefesa < poderAtaque) {

                int dano = poderAtaque - resistenciaDefesa;
                int vidaAtual = jogadorDefesa.getVidaJogador() - dano;
                jogadorDefesa.getCarta().setVivo(false);
                jogadorDefesa.setVidaJogador(vidaAtual);

                resistenciaDefesa = resistenciaDefesa - poderAtaque;
                jogadorDefesa.getCarta().setResistencia(resistenciaDefesa);


            } else {
                int vidaAtual = jogadorDefesa.getVidaJogador();
                jogadorDefesa.getCarta().setVivo(true);
                jogadorDefesa.setVidaJogador(vidaAtual);

                resistenciaDefesa = resistenciaDefesa - poderAtaque;
                jogadorDefesa.getCarta().setResistencia(resistenciaDefesa);
                //System.out.println("Nova resistencia apos o ataque: " + resistenciaDefesa);
            }
    }	
	
	//Novo
	public void desejaJogarDeNovo() {
		Scanner escolha = new Scanner(System.in);
		
		System.out.println("Desejam jogar outra partida?");
		System.out.println("1-Sim");
		System.out.println("2-Não");
		jogarDeNovo = escolha.nextInt();
		
		jogarDeNovo = this.getJogarDeNovo();
		
	}
	
	//Novo
	public void reiniciaPartida(Jogadores jogador1, Jogadores jogador2) {
		getListaCartas1().clear();
		getListaCartas2().clear();
		getCampoDeBatalha1().clear();
		getCampoDeBatalha2().clear();
		
		jogador1.setVidaJogador(20);
		jogador2.setVidaJogador(20);
		jogador1.setManaJogador(10);
		jogador2.setManaJogador(10);
		
		turno = 1;
	}

	public ArrayList<Carta> getListaCartas1() {
		return mao1;
	}

	public ArrayList<Carta> getListaCartas2() {
		return mao2;
	}

	public ArrayList<Carta> getCampoDeBatalha1() {
		return campoDeBatalha1;
	}

	public void setCampoDeBatalha1(ArrayList<Carta> campoDeBatalha1) {
		this.campoDeBatalha1 = campoDeBatalha1;
	}

	public ArrayList<Carta> getCampoDeBatalha2() {
		return campoDeBatalha2;
	}

	public void setCampoDeBatalha2(ArrayList<Carta> campoDeBatalha2) {
		this.campoDeBatalha2 = campoDeBatalha2;
	}

	public Jogadores getJogador() {
		return jogador;
	}

	public boolean getjogadorAtivo() {
		return isJogador1;
	}

	public int getJogarDeNovo() {
		return jogarDeNovo;
	}
	
	// public void cartasDisponiveis(Jogadores maoJogador1, Jogadores maoJogador2) {

	// ArrayList<Criatura> listaCriaturas1 = new ArrayList<Criatura>();
	// listaCriaturas1.add(maoJogador1.getCriatura().getNome());

	// ArrayList<Criatura> listaCriaturas2 = maoJogador2.getCriaturasLista();

	// }

}


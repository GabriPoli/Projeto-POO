package Cartas;

import java.awt.Image;

public abstract class Encantamento extends Carta {

    public Encantamento(int poder, int mana, int resistencia, String nome, String descricao, Image imagem) {
    super(poder, mana, resistencia, nome, descricao, imagem);

    }
 
}

package Criaturas;
import Cartas.Criatura;
import MecanicasJogo.Jogadores;
import javax.swing.ImageIcon;

public class Hidra extends Criatura {

    public Hidra() {

	super(4, 1, 2, 3,"Hidra", "Seu veneno esmagador avaba com seu inimigos apenas com o hálito!", new ImageIcon("src\\ImagensCartas\\cartaHidra.png").getImage());
    }

    @Override
    public void usarHabilidade(Jogadores jogador1, Jogadores jogador2) {
        jogador1.getCarta().setResistencia(jogador1.getCarta().getResistencia() + 3);
        jogador1.gastaMana(2);
    }
}

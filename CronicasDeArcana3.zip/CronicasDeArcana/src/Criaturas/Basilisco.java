package Criaturas;

import Cartas.Criatura;
import MecanicasJogo.Jogadores;

public class Basilisco extends Criatura{

		public Basilisco() {

			super(6, 4, 0, 7, "Basilisco", "-", null);
		}

    @Override
    public void usarHabilidade(Jogadores jogador1, Jogadores jogador2) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

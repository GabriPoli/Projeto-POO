package Criaturas;

import Cartas.Criatura;
import MecanicasJogo.Jogadores;

public class Sereia extends Criatura{

	public Sereia() {
		super(3, 1, 0, 3, "Sereia", "-", null);
	}


    @Override
    public void usarHabilidade(Jogadores jogador1, Jogadores jogador2) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

package Criaturas;

import java.util.Scanner;

import Cartas.Criatura;
import MecanicasJogo.Jogadores;
import javax.swing.ImageIcon;

public class Grifo extends Criatura {

	public Grifo() {

		super(5, 1, 3, 2, "Grifo", "Poderosa criatura alada que peregrina por toda Arcadia!", new ImageIcon("src\\ImagensCartas\\cartaGrifo.png").getImage());
	}

	public void habilidadeEspecial(Jogadores jogador, Criatura congelada) {
		
		System.out.println("Uso de Habilidade Especial!!!");
		for(int turnos = 0; turnos < 1; turnos++) {
			
		}
	
        }

    @Override
    public void usarHabilidade(Jogadores jogador1, Jogadores jogador2) {
        jogador2.setManaJogador(jogador2.getManaJogador() - 3);
        jogador1.gastaMana(3);
    }
}

package Criaturas;
import Cartas.Criatura;
import MecanicasJogo.Jogadores;
import javax.swing.ImageIcon;

public class Minotauro extends Criatura{

	public Minotauro() {
		
		super(7, 3, 2, 4, "Minotauro", "Ele vaga e acaba com qualquer um que pise no seu labirinto.", new ImageIcon("src\\ImagensCartas\\cartaMinotauro.png").getImage());
	}

    @Override
    public void usarHabilidade(Jogadores jogador1, Jogadores jogador2) {
        int novoPoder = jogador1.getCarta().getPoder() + 2;
        jogador1.getCarta().setPoder(novoPoder);
        int novaResistencia = jogador1.getCarta().getResistencia() - 2;
        jogador1.getCarta().setResistencia(novaResistencia);
        
	System.out.println("Minotauro agora possui o poder de " + jogador1.getCarta().getPoder() + " e a resistencia de " + jogador1.getCarta().getResistencia());
	jogador1.gastaMana(2);
    }
	
}

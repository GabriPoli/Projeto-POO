package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;


public class InterfaceDeArcana extends JFrame {
	 private JPanel campoDeBatalha1, campoDeBatalha2, maoJogador1Panel, maoJogador2Panel, cemiterioJogador1, cemiterioJogador2;
	    private JLabel lblVidaJogador1, lblManaJogador1, lblVidaJogador2, lblManaJogador2, lblNomeJogador1, lblNomeJogador2;
	    private ArrayList<CartaGui> todasCartas, maoJogador1, maoJogador2;  // Todas as cartas disponíveis e as mãos dos jogadores

	    public InterfaceDeArcana() {
	        setTitle("Crônicas de Arcana");
	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        setSize(1280, 720);
	        setLayout(null);

	        // Inicialização das cartas disponíveis e distribuição das cartas para cada jogador
	        todasCartas = new ArrayList<>();
	        inicializarCartasDisponiveis();
	        maoJogador1 = new ArrayList<>();
	        maoJogador2 = new ArrayList<>();
	        distribuirCartas();

	        // Jogador 1 - Info, Mão e Cemitério
	        lblNomeJogador1 = new JLabel("Jogador 1: Freitas");
	        lblNomeJogador1.setBounds(10, 580, 150, 30);
	        add(lblNomeJogador1);

	        lblVidaJogador1 = new JLabel("Vida: 20");
	        lblVidaJogador1.setBounds(10, 620, 100, 30);
	        add(lblVidaJogador1);

	        lblManaJogador1 = new JLabel("Mana: 10");
	        lblManaJogador1.setBounds(10, 660, 100, 30);
	        add(lblManaJogador1);

	        cemiterioJogador1 = new JPanel();
	        cemiterioJogador1.setBounds(200, 550, 100, 100);
	        cemiterioJogador1.setBorder(BorderFactory.createTitledBorder("Cemitério Jogador 1"));
	        add(cemiterioJogador1);

	        maoJogador1Panel = new JPanel();
	        maoJogador1Panel.setBounds(350, 580, 600, 100);
	        maoJogador1Panel.setLayout(new GridLayout(1, 5, 10, 10));
	        maoJogador1Panel.setPreferredSize(new Dimension(1200, 300));
	        maoJogador1Panel.setBorder(BorderFactory.createTitledBorder("Mão Jogador 1"));
	        add(maoJogador1Panel);

	        // Campo de Batalha Jogador 1
	        campoDeBatalha1 = new JPanel();
	        campoDeBatalha1.setBounds(350, 350, 600, 100);
	        campoDeBatalha1.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
	        campoDeBatalha1.setPreferredSize(new Dimension(1000, 300));
	        campoDeBatalha1.setBorder(BorderFactory.createTitledBorder("Campo de Batalha Jogador 1"));
	        add(campoDeBatalha1);

	        // Jogador 2 - Info, Mão e Cemitério
	        lblNomeJogador2 = new JLabel("Jogador 2: Leal");
	        lblNomeJogador2.setBounds(10, 10, 150, 30);
	        add(lblNomeJogador2);

	        lblVidaJogador2 = new JLabel("Vida: 20");
	        lblVidaJogador2.setBounds(10, 50, 100, 30);
	        add(lblVidaJogador2);

	        lblManaJogador2 = new JLabel("Mana: 10");
	        lblManaJogador2.setBounds(10, 90, 100, 30);
	        add(lblManaJogador2);

	        cemiterioJogador2 = new JPanel();
	        cemiterioJogador2.setBounds(200, 50, 100, 100);
	        cemiterioJogador2.setBorder(BorderFactory.createTitledBorder("Cemitério Jogador 2"));
	        add(cemiterioJogador2);

	        maoJogador2Panel = new JPanel();
	        maoJogador2Panel.setBounds(350, 10, 600, 100);
	        maoJogador2Panel.setLayout(new GridLayout(1, 5, 10, 10));
	        maoJogador2Panel.setPreferredSize(new Dimension(1200, 300));
	        maoJogador2Panel.setBorder(BorderFactory.createTitledBorder("Mão Jogador 2"));
	        add(maoJogador2Panel);

	        // Campo de Batalha Jogador 2
	        campoDeBatalha2 = new JPanel();
	        campoDeBatalha2.setBounds(350, 200, 600, 100);
	        campoDeBatalha2.setLayout(new GridLayout(1, 3, 10, 10));
	        campoDeBatalha2.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
	        campoDeBatalha2.setPreferredSize(new Dimension(1000, 300));
	        campoDeBatalha2.setBorder(BorderFactory.createTitledBorder("Campo de Batalha Jogador 2"));
	        add(campoDeBatalha2);

	        // Adicionar as cartas da mão do Jogador 1
	        for (CartaGui carta : maoJogador1) {
	            JButton btnCarta = new JButton(new ImageIcon(carta.getImagem()));
	            btnCarta.addActionListener(new ActionListener() {
	                @Override
	                public void actionPerformed(ActionEvent e) {
	                    adicionarCartaAoCampo(campoDeBatalha1, carta);
	                    maoJogador1Panel.remove(btnCarta);
	                    maoJogador1Panel.revalidate();
	                    maoJogador1Panel.repaint();
	                }
	            });
	            maoJogador1Panel.add(btnCarta);
	        }

	        // Adicionar as cartas da mão do Jogador 2
	        for (CartaGui carta : maoJogador2) {
	            JButton btnCarta = new JButton(new ImageIcon(carta.getImagem()));
	            btnCarta.addActionListener(new ActionListener() {
	                @Override
	                public void actionPerformed(ActionEvent e) {
	                    adicionarCartaAoCampo(campoDeBatalha2, carta);
	                    maoJogador2Panel.remove(btnCarta);
	                    maoJogador2Panel.revalidate();
	                    maoJogador2Panel.repaint();
	                }
	            });
	            maoJogador2Panel.add(btnCarta);
	        }

	        setVisible(true);
	    }

	    // Método para adicionar uma carta ao campo de batalha de um jogador
	    public void adicionarCartaAoCampo(JPanel campo, CartaGui carta) {
	        JButton btnCarta = new JButton(new ImageIcon(carta.getImagem()));
	        campo.add(btnCarta);
	        campo.revalidate();
	        campo.repaint();
	    }

	    // Método para inicializar todas as cartas disponíveis no jogo
	    public void inicializarCartasDisponiveis() {
	        todasCartas.add(new CartaGui("Hidra", "C://Cartas jogo Cronicas de Arcana//carta3.png", 5, 5));
	        todasCartas.add(new CartaGui("Minotauro", "C://Cartas jogo Cronicas de Arcana//carta2.png", 7, 4));
	        todasCartas.add(new CartaGui("Grifo", "C://Cartas jogo Cronicas de Arcana//carta4.png", 5, 2));
	        todasCartas.add(new CartaGui("Carbero", "C://Cartas jogo Cronicas de Arcana//carta1.png", 8, 4));
	        // Adicione mais cartas conforme necessário
	    }

	    // Método para distribuir cartas de forma aleatória para cada jogador
	    public void distribuirCartas() {
	        // Embaralhar as cartas antes de distribuir
	        Collections.shuffle(todasCartas);

	        // Verificar se há cartas suficientes para distribuir
	        int numCartasParaCadaJogador = Math.min(5, todasCartas.size() / 2);

	        // Dar as cartas para cada jogador
	        for (int i = 0; i < numCartasParaCadaJogador; i++) {
	            maoJogador1.add(todasCartas.get(i));
	            maoJogador2.add(todasCartas.get(i + numCartasParaCadaJogador));
	        }
	    }

	    public static void main(String[] args) {
	        new InterfaceDeArcana();
	    }
}


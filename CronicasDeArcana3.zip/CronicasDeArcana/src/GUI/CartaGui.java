package GUI;

public class CartaGui {

	private String nome;
    private String imagem;
    private int ataque;
    private int defesa;

    public CartaGui(String nome, String imagem, int ataque, int defesa) {
        this.nome = nome;
        this.imagem = imagem;
        this.ataque = ataque;
        this.defesa = defesa;
    }

    public String getNome() {
        return nome;
    }

    public String getImagem() {
        return imagem;
    }

    public int getAtaque() {
        return ataque;
    }

    public int getDefesa() {
        return defesa;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;
import Cartas.*;
import Criaturas.*;
import javax.swing.*;

/**
 *
 * @author gabri
 */
public class ObjetoCartaDaMao {
    
    public void setCartasDaMao(int numeroCarta){
        Carta carta;
        switch(numeroCarta){
            case 1: carta = new Cerbero();break;
            case 2: carta = new Minotauro();break;
            case 3: carta = new Grifo();break;
            case 4: carta = new Hidra();break;
            default:carta = null;
        }
    }
}

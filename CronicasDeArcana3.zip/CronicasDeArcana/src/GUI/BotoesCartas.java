package GUI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class BotoesCartas extends JPanel{

    JButton cartaJogador1;
    JButton cartaJogador2;

    public BotoesCartas() {
        setSize(1200, 400);
        setVisible(true);
        setLayout(null); // Usar posicionamento absoluto

        ImageIcon carta1 = new ImageIcon("C://Cartas jogo Cronicas de Arcana//cartaCerbero01.png");
        ImageIcon carta2 = new ImageIcon("C://Cartas jogo Cronicas de Arcana//cartaMinotauro02.png");

        cartaJogador1 = new JButton(carta1);
        cartaJogador1.setBounds(50, 400, carta1.getIconWidth(), carta1.getIconHeight());

        cartaJogador2 = new JButton(carta2);
        cartaJogador2.setBounds(1000, 400, carta2.getIconWidth(), carta2.getIconHeight()); // Use as dimensões da carta2

        JPanel opcoesCarta = new JPanel();
        JButton atacar = new JButton("Atacar");
        JButton habilidade = new JButton("Habilidade");

        opcoesCarta.setLayout(new FlowLayout()); // Adicionar layout ao painel de opções
        opcoesCarta.add(atacar);
        opcoesCarta.add(habilidade);
        opcoesCarta.setVisible(false);
        opcoesCarta.setBounds(400, 500, 300, 100); // Definir posição para o painel de opções

        // Adicionar componentes ao painel principal
        add(cartaJogador1);
        add(cartaJogador2);
        add(opcoesCarta);

        cartaJogador1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                opcoesCarta.setVisible(!opcoesCarta.isVisible());
            }
        });

        cartaJogador2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                opcoesCarta.setVisible(!opcoesCarta.isVisible());
            }
        });
    }
}
